var secret = 0;
var guesses = 0;

console.log("Secret: " + secret); // diagnostic print; for testing only

function onClick() {

    // INSERT YOUR CODE HERE

}

function validate(guess) {

    var result = false;

    // INSERT YOUR CODE HERE

    return result;

}